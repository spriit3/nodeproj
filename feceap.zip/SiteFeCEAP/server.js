// 1 - Iniciar o projeto Node :
// 2 - npm init -y

// 3 - Instalar o framework Express :
//npm i express 
// ou npm install express

//4 Instalar nodemon

const express = require("express")
const { listenerCount} = require("process")
const server = express()

server.use(express.static("public"))

console.log("It's ALIVE!!!!")

//Rota raiz = origem

server.get("/", function(req, res){
    res.sendFile(__dirname+"/index.html")
})
server.get("/teste", function(req, res){
    console.log("Teste dessa maravilha do webdevelopment")
    res.send("Enviei do beck de novo 🚬🚬🚬🚬🚬🚬")
})
server.get("/projetos", function(req, res){
    res.sendFile(__dirname+"/projects.html")
})

server.listen(3000)
function onOff() {
    document.getElementById("modal")
    .classList
    .toggle("hide")
}